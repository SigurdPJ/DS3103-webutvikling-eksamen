import AppRouting from "./routing/AppRouting"
import 'bootstrap/dist/css/bootstrap.min.css'

function App() {

  return (
    <>
      <AppRouting/>
    </>
  )

}

export default App
