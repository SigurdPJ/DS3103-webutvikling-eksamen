import MerchList from "./MerchList";

const ShowAllMerch = () => {

    return (
        <>
            <header className="p-2 m-4 text-center">
                <h3>Trump Merch</h3>
            </header>

            <MerchList/>
        </>
    )
}

export default ShowAllMerch;