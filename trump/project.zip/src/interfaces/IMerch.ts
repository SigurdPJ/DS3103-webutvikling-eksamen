interface IMerch{
    id?: number,
    name?: string,
    type?: string,
    price: number,
    inStock: number
    image: string
}

export default IMerch;