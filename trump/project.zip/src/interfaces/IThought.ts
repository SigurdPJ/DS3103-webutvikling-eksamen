interface IThought{
    id?: number,
    phrase?: string,
    category?: string,
}

export default IThought;